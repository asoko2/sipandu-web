<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class VerifikatorSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('verifikators')->insert([
            ['no' => 1, 'user_id' => 2],
            ['no' => 2, 'user_id' => 3],
            ['no' => 3, 'user_id' => 4],
            ['no' => 4, 'user_id' => 5],
            ['no' => 5, 'user_id' => 6],
            ['no' => 6, 'user_id' => 7],
        ]);
    }
}
